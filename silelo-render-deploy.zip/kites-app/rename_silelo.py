def patch(path, pairs):
    s = open(path, encoding='utf-8').read()
    ok = True
    for old, new in pairs:
        if old not in s:
            print(f'  !! NOT FOUND in {path}: {old[:55]!r}')
            ok = False
            continue
        s = s.replace(old, new, 1)
    if ok:
        open(path, 'w', encoding='utf-8').write(s)
        print(f'  OK {path}')
    else:
        print(f'  SKIPPED {path}')

# ============ index.html ============
print('index.html:')
patch('/kites-app/public/index.html', [
    ('<title>Kites Mobile App</title>', '<title>Silelo💯✨️</title>'),
    ('<meta name="description" content="Kites Mobile App — แอปพลิเคชันมือถือ AI ครบวงจร: AI Assistant, แชทเรียลไทม์, แผนที่, ชำระเงิน และ Analytics">',
     '<meta name="description" content="Silelo💯✨️ — แอปพลิเคชันมือถือ AI ครบวงจร: AI Assistant, แชทเรียลไทม์, แผนที่, ชำระเงิน และ Analytics">'),
    ('<h1>Kites<span>App</span></h1>', '<h1>Silelo<span>💯✨️</span></h1>'),
    ('แอปพลิเคชันมือถือ AI — ออกแบบและพัฒนาโดย Kites Design', 'แอปพลิเคชันมือถือ AI — ออกแบบและพัฒนาโดย Silelo'),
    ('✨ เข้าสู่ระบบด้วยบัญชีทดลอง (demo@kites.app)', '✨ เข้าสู่ระบบด้วยบัญชีทดลอง (demo@silelo.app)'),
    ('<input type="text" id="in-name" placeholder="เช่น สมชาย ใจดี" autocomplete="name">', '<input type="text" id="in-name" placeholder="เช่น Bossnu" autocomplete="name">'),
    ('<div class="h-title">Kites<span>App</span></div>', '<div class="h-title">Silelo<span>💯✨️</span></div>'),
    ('<div class="welcome-name" id="welcome-name">คุณสมชาย</div>', '<div class="welcome-name" id="welcome-name">Bossnu</div>'),
    ('<h2>Kites AI</h2>', '<h2>Silelo AI</h2>'),
    ('ผมคือ Kites AI 🤖', 'ผมคือ Silelo AI 🤖'),
    ('สำนักงาน Kites Design · Dhaka, Bangladesh', 'สำนักงาน Silelo · Dhaka, Bangladesh'),
    ('<b>Kites Design HQ</b>', '<b>Silelo HQ</b>'),
    ('สำนักงานใหญ่ — Dhaka</b><small>Kites Design HQ · Gulshan</small>', 'สำนักงานใหญ่ — Dhaka</b><small>Silelo HQ · Gulshan</small>'),
    ('<p id="profile-email">demo@kites.app</p>', '<p id="profile-email">demo@silelo.app</p>'),
    ('<h2 id="profile-name">คุณสมชาย</h2>', '<h2 id="profile-name">Bossnu</h2>'),
    ('เกี่ยวกับ Kites Design</b><small>ทีมออกแบบว่าว · PRO</small>', 'เกี่ยวกับ Silelo</b><small>ทีมออกแบบ · PRO</small>'),
    ('<h3>Kites Design</h3>', '<h3>Silelo💯✨️</h3>'),
])

# ============ app.js ============
print('app.js:')
patch('/kites-app/public/app.js', [
    ('/* ============ Kites Mobile App — App Logic ============ */', '/* ============ Silelo💯✨️ — App Logic ============ */'),
    ("email: 'demo@kites.app'", "email: 'demo@silelo.app'"),
    ('Kites AI · กำลังตอบ...', 'Silelo AI · กำลังตอบ...'),
    ("title: 'Kites Design HQ'", "title: 'Silelo HQ'"),
])

# ============ server.js ============
print('server.js:')
patch('/kites-app/server.js', [
    (' * Kites Design — Mobile App Backend', ' * Silelo💯✨️ — Mobile App Backend'),
    ("const JWT_SECRET = process.env.JWT_SECRET || 'kites-design-secret-2025';", "const JWT_SECRET = process.env.JWT_SECRET || 'silelo-secret-2025';"),
    ("      name: 'คุณสมชาย นักพัฒนา',\n      email: 'demo@kites.app',", "      name: 'Bossnu',\n      email: 'demo@silelo.app',"),
    ("user: 'Kites Support'", "user: 'Silelo Support'"),
    ('ยินดีต้อนรับสู่ Kites Design!', 'ยินดีต้อนรับสู่ Silelo! 💯✨️'),
    ('✅ Kites Mobile App backend กำลังทำงานที่', '✅ Silelo💯✨️ backend กำลังทำงานที่'),
])

# ============ manifest.json ============
print('manifest.json:')
patch('/kites-app/public/manifest.json', [
    ('"name": "Kites Mobile App — แอปพลิเคชันมือถือ AI"', '"name": "Silelo💯✨️ — แอปพลิเคชันมือถือ AI"'),
    ('"short_name": "KitesApp"', '"short_name": "Silelo"'),
    ('โดย Kites Design: AI Assistant', 'โดย Silelo: AI Assistant'),
])

# ============ package.json ============
print('package.json:')
patch('/kites-app/package.json', [
    ('"name": "kites-mobile-app"', '"name": "silelo-mobile-app"'),
    ('"description": "Kites Design — แอปพลิเคชันมือถือ AI ครบวงจร (สเป็คแพ็กเกจ $12,999)"', '"description": "Silelo💯✨️ — แอปพลิเคชันมือถือ AI ครบวงจร (สเป็คแพ็กเกจ $12,999)"'),
])

# ============ sw.js ============
print('sw.js:')
patch('/kites-app/public/sw.js', [
    ('/* Kites Mobile App — Service Worker (PWA) */', '/* Silelo💯✨️ — Service Worker (PWA) */'),
    ("const CACHE = 'kites-app-v4';", "const CACHE = 'silelo-app-v5';"),
    ("'/style.css?v=4'", "'/style.css?v=5'"),
    ("'/app.js?v=4'", "'/app.js?v=5'"),
])

print('DONE')
