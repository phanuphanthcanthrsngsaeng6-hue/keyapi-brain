# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

# แก้เฉพาะใน aiSystemPrompt (ระหว่าง function ถึง aiMockReply)
start = src.find('function aiSystemPrompt')
end = src.find('function aiMockReply')
if start != -1 and end != -1:
    block = src[start:end]
    block2 = block.replace('พี่บอส', 'พี่นุ').replace('BossNu', 'ภาณุพันธ์')
    src = src[:start] + block2 + src[end:]
    print('✅ แก้พี่บอส → พี่นุ ใน system prompt')
else:
    print('❌ หาไม่พบ')

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
