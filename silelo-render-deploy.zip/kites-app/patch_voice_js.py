# -*- coding: utf-8 -*-
js = open('/kites-app/public/app.js', encoding='utf-8').read()

# ========== เพิ่มระบบเสียง (Voice) ต่อท้าย app.js ==========
voice_js = r"""
/* ================== 📞 ระบบโทรคุยเสียงสลี่ (ตามโครงการ Silelo) ================== */
let voiceRec = null, voiceChunks = [], voiceRecording = false, voiceContinuous = false, voicePlaying = false, voiceLoopTimer = null;

function voiceStatus(txt, cls) {
  const el = $('#voice-status');
  if (el) el.textContent = txt;
  const orb = $('#voice-orb');
  if (orb) orb.className = 'voice-orb' + (cls ? ' ' + cls : '');
}

function voiceSay(txt) { // แสดงคำพูดที่ได้ยิน
  const el = $('#voice-last');
  if (el) el.innerHTML = '<div class="voice-bubble">🗣 ' + txt + '</div>';
}

async function loadMemories() {
  try {
    const d = await api('/api/memories');
    const wrap = $('#voice-memories'), list = $('#voice-mem-list');
    if (d.ok && d.memories && d.memories.length) {
      list.innerHTML = d.memories.slice().reverse().slice(0, 8).map(m => '<div class="mem-chip">💍 ' + m.fact + '</div>').join('');
      wrap.style.display = 'block';
    } else wrap.style.display = 'none';
  } catch (e) {}
}

function ensureVoiceScreen() { if (currentTab === 'voice') loadMemories(); }

// —— บันทึกเสียง (กดค้างพูด) ——
async function pttStart(e) {
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (voiceRecording) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    alert('เบราว์เซอร์นี้ไม่รองรับไมโครโฟน — ใช้ Chrome/Safari ล่าสุด');
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    voiceChunks = [];
    voiceRec = new MediaRecorder(stream);
    voiceRec.ondataavailable = ev => { if (ev.data.size) voiceChunks.push(ev.data); };
    voiceRec.onstop = () => { stream.getTracks().forEach(t => t.stop()); processVoice(); };
    voiceRec.start();
    voiceRecording = true;
    voiceStatus('🎤 สลี่กำลังฟังพี่นุ...', 'rec');
  } catch (err) {
    alert('ไม่สามารถเปิดไมโครโฟนได้: ' + err.message);
  }
}

function pttEnd(e) {
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (voiceRecording && voiceRec && voiceRec.state === 'recording') {
    voiceRec.stop();
    voiceRecording = false;
  }
}

async function processVoice() {
  if (!voiceChunks.length) { voiceStatus('ไม่ได้ยินเสียง — ลองอีกครั้ง'); return; }
  const blob = new Blob(voiceChunks, { type: voiceChunks[0].type || 'audio/webm' });
  voiceStatus('🧠 กำลังฟัง (Whisper)...', 'think');
  // STT
  let text = '';
  try {
    const fd = new FormData();
    fd.append('audio', blob, 'voice.' + (blob.type.includes('mp4') ? 'm4a' : 'webm'));
    const d = await api('/api/stt', { method: 'POST', body: fd, raw: true });
    if (!d.ok) { voiceStatus('⚠️ ' + (d.error || 'STT ล้มเหลว')); return; }
    text = d.text;
  } catch (e) { voiceStatus('⚠️ ไม่ได้ยินเสียง: ' + e.message); return; }
  voiceSay(text);
  // AI
  voiceStatus('💭 สลี่กำลังคิด...', 'think');
  let reply = '';
  try {
    const d = await api('/api/ai', { method: 'POST', body: JSON.stringify({ question: text, messages: [] }) });
    reply = d.reply || 'สลี่ฟังไม่ทันค่ะ';
  } catch (e) { reply = 'สลี่ขอโทษนะคะ ตอนนี้ติดขัดนิดหน่อย'; }
  // TTS + เล่นเสียง
  voiceStatus('🔊 สลี่กำลังพูด...', 'talk');
  try {
    const audio = await apiTTS(reply);
    if (audio) {
      const url = URL.createObjectURL(audio);
      const au = new Audio(url);
      voicePlaying = true;
      au.onended = () => { voicePlaying = false; URL.revokeObjectURL(url); afterVoiceReply(); };
      au.onerror = () => { voicePlaying = false; afterVoiceReply(); };
      await au.play();
    } else afterVoiceReply();
  } catch (e) { afterVoiceReply(); }
  const bubble = document.querySelector('#ai-chat');
  if (bubble) {
    const d = document.createElement('div');
    d.className = 'msg ai';
    d.innerHTML = '<div class="bubble">' + escapeHtml(reply) + '</div>';
    bubble.appendChild(d);
    bubble.scrollTop = bubble.scrollHeight;
  }
}

function afterVoiceReply() {
  if (voiceContinuous) {
    voiceStatus('🎧 โหมดคุยต่อเนื่อง — พูดได้เลย', 'cont');
    voiceLoopTimer = setTimeout(() => { if (voiceContinuous && !voiceRecording) pttStart(); }, 1200);
  } else {
    voiceStatus('กดปุ่มเพื่อคุยกับสลี่');
  }
}

// —— TTS: ขอเสียงจาก server ——
async function apiTTS(text) {
  try {
    const d = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (localStorage.getItem('silelo_token') || '') },
      body: JSON.stringify({ text: String(text).slice(0, 1900) })
    });
    if (!d.ok) return null;
    return await d.blob();
  } catch (e) { return null; }
}

// —— โหมดคุยต่อเนื่อง (กด 📞) ——
function toggleCallMode() {
  voiceContinuous = !voiceContinuous;
  const btn = $('#btn-callmode');
  if (btn) btn.classList.toggle('on', voiceContinuous);
  if (voiceContinuous) {
    voiceStatus('🎧 โหมดคุยต่อเนื่องเปิดแล้ว — สลี่พร้อมฟัง', 'cont');
    setTimeout(() => { if (voiceContinuous) pttStart(); }, 1500);
  } else {
    voiceStatus('กดปุ่มเพื่อคุยกับสลี่');
    clearTimeout(voiceLoopTimer);
  }
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
}
"""
js = js.rstrip() + "\n" + voice_js
open('/kites-app/public/app.js', 'w', encoding='utf-8').write(js)
print('✅ Voice logic เพิ่มแล้ว')

# ตรวจว่า api() รองรับ raw body (FormData) ไหม
print('--- ตรวจ api() function ---')
import re
m = re.search(r'async function api\(path, opts = \{\}\) \{.*?\n\}', js, re.S)
print(m.group(0)[:500] if m else 'ไม่พบ')
