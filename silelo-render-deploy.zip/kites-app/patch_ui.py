# -*- coding: utf-8 -*-
html = open('/kites-app/public/index.html', encoding='utf-8').read()

# ========== 1) เพิ่ม tab โทร ในแถบเมนูด้านล่าง (ตามโครงการ: ปุ่มหูฟัง/โทร) ==========
old_tab = """    <button class="tab" data-tab="chat" onclick="go('chat')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>แชท</span></button>"""
new_tab = """    <button class="tab" data-tab="chat" onclick="go('chat')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>แชท</span></button>
    <button class="tab call-tab" data-tab="voice" onclick="go('voice')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg><span>โทร</span></button>"""
assert old_tab in html
html = html.replace(old_tab, new_tab)

# ========== 2) เพิ่มหน้าจอโทร (voice screen) หลัง screen-ai ==========
voice_screen = """
    <!-- VOICE CALL (ระบบโทรคุยเสียงสลี่) -->
    <section class="screen chat-screen" id="screen-voice">
      <div class="screen-head">
        <div class="screen-avatar ai voice-pulse">📞</div>
        <div>
          <h2>สลี่ออลา</h2>
          <p id="voice-status">กดปุ่มเพื่อคุยกับสลี่</p>
        </div>
      </div>
      <div class="voice-stage">
        <div class="voice-orb" id="voice-orb">
          <div class="voice-orb-inner">💗</div>
        </div>
        <div class="voice-wave" id="voice-wave"></div>
        <p class="voice-hint" id="voice-hint">กดค้าง 🎤 เพื่อพูด · กด 📞 เพื่อโหมดคุยต่อเนื่อง</p>
        <div class="voice-last" id="voice-last"></div>
      </div>
      <div class="voice-controls">
        <button class="voice-btn" id="btn-ptt" aria-label="กดค้างเพื่อพูด">🎤 <small>กดค้างพูด</small></button>
        <button class="voice-btn call" id="btn-callmode" aria-label="โหมดคุยต่อเนื่อง">📞 <small>คุยต่อเนื่อง</small></button>
      </div>
      <div class="voice-memories" id="voice-memories" style="display:none">
        <h4>💍 ความทรงจำที่สลี่จำได้</h4>
        <div id="voice-mem-list"></div>
      </div>
    </section>
"""
anchor = "    <!-- CHAT -->"
assert anchor in html
html = html.replace(anchor, voice_screen + "\n" + anchor)

# ========== 3) ปุ่ม 🎤 ใน input bar ของ AI screen ==========
old_input = """      <div class="input-bar">
        <input id="ai-input" placeholder="พิมพ์ข้อความ..." onkeydown="if(event.key==='Enter')aiSend()">
        <button class="send-btn" onclick="aiSend()" aria-label="ส่ง"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button>
      </div>"""
new_input = """      <div class="input-bar">
        <input id="ai-input" placeholder="พิมพ์ข้อความ..." onkeydown="if(event.key==='Enter')aiSend()">
        <button class="mic-btn" id="ai-mic" aria-label="พูดกับสลี่" onmousedown="pttStart(event)" onmouseup="pttEnd(event)" onmouseleave="pttEnd(event)" ontouchstart="pttStart(event)" ontouchend="pttEnd(event)">🎤</button>
        <button class="send-btn" onclick="aiSend()" aria-label="ส่ง"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button>
      </div>"""
assert old_input in html
html = html.replace(old_input, new_input)

open('/kites-app/public/index.html', 'w', encoding='utf-8').write(html)
print('✅ UI ระบบโทรเพิ่มแล้ว (tab โทร + หน้าจอเสียง + ปุ่มไมค์)')
