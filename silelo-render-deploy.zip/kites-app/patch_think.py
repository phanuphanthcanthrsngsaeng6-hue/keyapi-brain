# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

old = """ผู้ที่กำลังคุยด้วยตอนนี้: ${isOwner ? 'พี่นุเอง (เจ้าของ) — ให้บริการเต็มที่ อบอุ่น กันเอง' : who + ' (ไม่ใช่พี่นุ — ให้ปฏิเสธสุภาพ ไม่ให้ข้อมูลใดๆ)'}`;"""
new = """ผู้ที่กำลังคุยด้วยตอนนี้: ${isOwner ? 'พี่นุเอง (เจ้าของ) — ให้บริการเต็มที่ อบอุ่น กันเอง' : who + ' (ไม่ใช่พี่นุ — ให้ปฏิเสธสุภาพ ไม่ให้ข้อมูลใดๆ)'}

กฎเหล็ก: ตอบเป็นภาษาไทยเสมอ ตอบตรงๆ ทันที ห้ามแสดงขั้นตอนการคิด (thinking process / analysis / reasoning steps) ห้ามตอบเป็นภาษาอังกฤษ ห้ามขึ้นต้นด้วย "Here's a thinking process"`;
"""
assert old in src
src = src.replace(old, new)
open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ เพิ่มกฎห้าม thinking process')
