# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

# ========== API เสียงสลี่ (TTS) + ฟังพี่นุ (STT) + ความทรงจำ ==========
anchor = "/* ---- AI สร้างภาพ (Ideogram → OpenRouter → Pollinations auto-fallback) ---- */"
tts_code = """/* ================== 🔊 ระบบเสียงสลี่ (Thai-TTS-Silelo-v1 + Whisper) ================== */
const TTS_VOICE = process.env.TTS_VOICE || 'th-TH-PremwadeeNeural'; // เสียงผู้หญิงไทยอ่อนหวาน (ฟรี ไม่ต้องคีย์)
const GROQ_API_KEY = process.env.GROQ_API_KEY || ''; // สำหรับ Whisper STT — สมัครฟรีที่ console.groq.com

// 🔊 ข้อความ → เสียงสลี่ (edge-tts ฟรี)
app.post('/api/tts', auth, async (req, res) => {
  const text = ((req.body || {}).text || '').toString().trim();
  if (!text) return res.status(400).json({ ok: false, error: 'ไม่มีข้อความ' });
  if (text.length > 2000) return res.status(400).json({ ok: false, error: 'ข้อความยาวเกินไป' });
  const outFile = path.join(os.tmpdir(), 'sali_' + Date.now() + '_' + Math.floor(Math.random() * 9999) + '.mp3');
  execFile('python3', ['-m', 'edge_tts', '--voice', TTS_VOICE, '--text', text, '--write-media', outFile], { timeout: 45000 }, (err) => {
    if (err || !fs.existsSync(outFile)) {
      try { fs.unlinkSync(outFile); } catch (e) {}
      return res.status(500).json({ ok: false, error: 'TTS ล้มเหลว: ' + (err ? err.message : 'ไม่มีไฟล์') });
    }
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('X-Sali-Voice', TTS_VOICE);
    fs.createReadStream(outFile).on('close', () => { try { fs.unlinkSync(outFile); } catch (e) {} }).pipe(res);
  });
});

// 🎤 เสียงพี่นุ → ข้อความ (Whisper Large v3 ผ่าน Groq — สมัครคีย์ฟรี)
app.post('/api/stt', auth, upload.single('audio'), async (req, res) => {
  if (!GROQ_API_KEY) return res.status(400).json({ ok: false, error: 'ยังไม่ได้ตั้งคีย์ Groq — สมัครฟรีที่ https://console.groq.com แล้วใส่ GROQ_API_KEY' });
  if (!req.file || !req.file.buffer || !req.file.buffer.length) return res.status(400).json({ ok: false, error: 'ไม่พบไฟล์เสียง' });
  try {
    const fd = new FormData();
    fd.append('model', 'whisper-large-v3');
    fd.append('language', 'th');
    fd.append('file', new Blob([req.file.buffer], { type: req.file.mimetype || 'audio/webm' }), 'voice.webm');
    const r = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + GROQ_API_KEY },
      body: fd
    });
    const j = await r.json();
    if (!r.ok) throw new Error((j.error && j.error.message) || ('Groq ' + r.status));
    const text = (j.text || '').trim();
    if (!text) return res.status(422).json({ ok: false, error: 'ไม่ได้ยินเสียง — ลองพูดอีกครั้ง' });
    res.json({ ok: true, text, model: 'Whisper Large v3' });
  } catch (e) {
    res.status(500).json({ ok: false, error: 'STT ล้มเหลว: ' + e.message });
  }
});

// 💍 ความทรงจำถาวร — ดู/เพิ่ม
app.get('/api/memories', auth, (req, res) => {
  const uid = req_user_id(req.user);
  res.json({ ok: true, memories: (db.memories && db.memories[uid]) || [] });
});

app.post('/api/memories', auth, (req, res) => {
  const fact = ((req.body || {}).fact || '').toString().trim();
  if (!fact || fact.length > 500) return res.status(400).json({ ok: false, error: 'ความทรงจำไม่ถูกต้อง' });
  const uid = req_user_id(req.user);
  if (!db.memories) db.memories = {};
  if (!db.memories[uid]) db.memories[uid] = [];
  db.memories[uid].push({ fact, at: new Date().toISOString() });
  if (db.memories[uid].length > 100) db.memories[uid] = db.memories[uid].slice(-100);
  saveDB(db);
  res.json({ ok: true, memories: db.memories[uid] });
});

/* ---- AI สร้างภาพ (Ideogram → OpenRouter → Pollinations auto-fallback) ---- */"""
assert anchor in src
src = src.replace(anchor, tts_code)

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ API ระบบเสียง (TTS/STT) + ความทรงจำ เพิ่มแล้ว')
