# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

# 1) โหลด .env ถ้ามี (ไม่ต้องพึ่ง package) — ใส่หลัง require ทั้งหลาย
anchor = "const PORT = process.env.PORT || 8080;"
loader = """// โหลด .env (เฉพาะ local dev — บน Render ใช้ env vars แดชบอร์ด)
try { require('fs').readFileSync(__dirname + '/.env', 'utf8').split(/\\r?\\n/).forEach(l => {
  const m = l.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/); if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
}); } catch (e) {}

"""
assert anchor in src
src = src.replace(anchor, loader + anchor)
open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ server.js โหลด .env แล้ว')

import subprocess, time
subprocess.run(['bash','-c','fuser -k 8080/tcp 2>/dev/null; sleep 1; cd /kites-app && (setsid node server.js > /tmp/kites-app.log 2>&1 < /dev/null &)'], check=True)
time.sleep(2)
print('✅ restart แล้ว')
