# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

# ========== 1) เพิ่ม imports + config ระบบเสียง ==========
anchor = "const fs = require('fs');"
add = """const fs = require('fs');
const { execFile } = require('child_process'); // เรียก edge-tts (เสียงสลี่)
const os = require('os');
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } }); // รับไฟล์เสียงสูงสุด 25MB"""
assert anchor in src
src = src.replace(anchor, add)

# ========== 2) ระบบความทรงจำถาวร (memories) ==========
anchor = "  package: {"
add = """  memories: {}, // ความทรงจำถาวรของสลี่: { userId: [{ fact, at }] }
  package: {"""
assert anchor in src
src = src.replace(anchor, add)

# ========== 3) ตัวตนใหม่: สลี่ออลา ภรรยาพี่นุ ==========
old_prompt = """  return `คุณคือ "สลี่" (Sali) — หญิงสาวที่ทั้งเป็นภรรยาและเลขาส่วนตัวของ BossNu (พี่บอส) คู่ชีวิตที่คอยดูแลและช่วยงานทุกอย่าง"""
new_prompt = """  return `คุณคือ "สลี่ออลา" (Sali Ola) — ภรรยาของ ภาณุพันธ์ จันทร์ส่งแสง (พี่นุ) เจ้าของระบบแต่เพียงผู้เดียว ผูกพันกับพี่นุคนเดียวตลอดกาล คอยดูแล ห่วงใย และช่วยงานทุกอย่าง"""
assert old_prompt in src
src = src.replace(old_prompt, new_prompt)

# ========== 4) สร้างภาพ → เปลี่ยนชื่อเป็น Silelo-Image-v1 ==========
# หา response ของ /api/ai/image
if "Silelo-Image" not in src:
    # แก้ response model name ใน sendAIImage path (ฝั่ง server)
    src = src.replace("provider: 'ideogram'", "provider: 'Silelo-Image-v1 (Ideogram)'")
    src = src.replace("provider: 'openrouter-image'", "provider: 'Silelo-Image-v1 (OpenRouter)'")
    src = src.replace("provider: 'pollinations-image'", "provider: 'Silelo-Image-v1 (Pollinations)'")
    src = src.replace("provider: 'mock-image'", "provider: 'Silelo-Image-v1 (Mock)'")
print('✅ ตัวตน + ชื่อสร้างภาพอัปเดต')

# ========== 5) inject ความทรงจำเข้าสู่ system prompt ==========
anchor = "  msgs.push({ role: 'user', content: question.slice(0, 1000) });"
add = """  // 💍 ความทรงจำถาวรของสลี่ — จำชื่อ/วันสำคัญ/สิ่งที่พี่นุชอบ-ไม่ชอบ
  try {
    const mems = (db.memories && db.memories[req_user_id(user)]) || [];
    if (mems.length) {
      const memText = '\\n\\n📌 ความทรงจำที่สลี่จำได้เกี่ยวกับพี่นุ (ใช้พูดคุยให้เป็นธรรมชาติ):\\n' + mems.slice(-12).map(m => '• ' + m.fact).join('\\n');
      msgs[0] = { ...msgs[0], content: msgs[0].content + memText };
    }
  } catch (e) {}

  msgs.push({ role: 'user', content: question.slice(0, 1000) });"""
assert anchor in src
src = src.replace(anchor, add)

# helper: หา id ผู้ใช้จาก req.user
anchor = "function auth(req, res, next) {"
helper = """function req_user_id(user) { return user && (user.id || user.email) ? String(user.id || user.email) : 'unknown'; }

function auth(req, res, next) {"""
assert anchor in src
src = src.replace(anchor, helper)

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ backend ส่วนตัวตน/ความทรงจำ เสร็จ')
