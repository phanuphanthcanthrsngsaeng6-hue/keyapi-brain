# -*- coding: utf-8 -*-
# อัปเดต render.yaml + .env.example ให้มีระบบเสียง
ry = open('/kites-app/render.yaml', encoding='utf-8').read()
old = """      - key: DEEPSEEK_MODEL
        value: deepseek-v4-flash"""
new = """      - key: DEEPSEEK_MODEL
        value: deepseek-v4-flash
      # 🎤 เสียงสลี่ (ฟรี ไม่ต้องคีย์)
      - key: TTS_VOICE
        value: th-TH-PremwadeeNeural
      # 🎧 Whisper STT — สมัครคีย์ฟรีที่ console.groq.com
      - key: GROQ_API_KEY
        value: """""
assert old in ry
ry = ry.replace(old, new)
open('/kites-app/render.yaml', 'w', encoding='utf-8').write(ry)
print('✅ render.yaml เพิ่มระบบเสียง')

env = open('/kites-app/.env.example', encoding='utf-8').read()
env += """
# 🔊 ระบบเสียงสลี่
TTS_VOICE=th-TH-PremwadeeNeural
# 🎧 Whisper Large v3 (STT) — สมัครคีย์ฟรีที่ https://console.groq.com
GROQ_API_KEY=
"""
open('/kites-app/.env.example', 'w', encoding='utf-8').write(env)
print('✅ .env.example เพิ่มระบบเสียง')

# update README-DEPLOY ให้สั้นๆ เพิ่มหัวข้อเสียง
rd = open('/kites-app/README-DEPLOY.md', encoding='utf-8').read()
rd += """
## 🔊 ระบบเสียงสลี่ (ใหม่)
- **TTS (เสียงสลี่พูด)**: ฟรี ไม่ต้องคีย์ — ใช้ `th-TH-PremwadeeNeural` (ผู้หญิงไทย อ่อนหวาน)
- **STT (ฟังพี่นุ)**: ต้องมีคีย์ Groq ฟรี → https://console.groq.com → ตั้ง `GROQ_API_KEY`
- ปุ่ม **โทร** ในแถบเมนูด้านล่าง: กดค้าง 🎤 = พูด / กด 📞 = โหมดคุยต่อเนื่อง
- ความทรงจำถาวร: สลี่จำสิ่งที่พี่นุสอนผ่าน `/api/memories`
"""
open('/kites-app/README-DEPLOY.md', 'w', encoding='utf-8').write(rd)
print('✅ README อัปเดต')
