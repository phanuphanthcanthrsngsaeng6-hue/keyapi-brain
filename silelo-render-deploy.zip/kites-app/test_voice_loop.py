# -*- coding: utf-8 -*-
# ทดสอบวงจรโทรครบ: เสียงพี่นุ → Whisper → AI → เสียงสลี่
import subprocess, json, time, urllib.request

BASE = 'http://localhost:8080'

def req(method, path, token=None, data=None, form=None, out=None):
    url = BASE + path
    if form:
        # multipart via curl (ง่ายสุด)
        cmd = ['curl','-s','-m','120','-X','POST',url]
        if token: cmd += ['-H','Authorization: Bearer '+token]
        for k,v in form.items():
            cmd += ['-F', f'{k}={v}']
        r = subprocess.run(cmd, capture_output=True, text=True)
        return json.loads(r.stdout)
    body = json.dumps(data).encode() if data else None
    rq = urllib.request.Request(url, data=body, method=method)
    if token: rq.add_header('Authorization', 'Bearer '+token)
    if body: rq.add_header('Content-Type','application/json')
    try:
        with urllib.request.urlopen(rq, timeout=120) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return json.loads(e.read().decode())

tok = req('POST','/api/login',data={'email':'demo@silelo.app','password':'demo1234'})['token']
print('✅ เข้าสู่ระบบ')

# STEP 1: เสียงพี่นุพูด (สร้างเสียง) → Whisper ถอดความ
subprocess.run(['bash','-c','edge-tts --voice th-TH-PremwadeeNeural --text "สวัสดีจ้ะสลี่ วันนี้พี่นุเหนื่อยมาก อยากได้กำลังใจหน่อย" --write-media /tmp/pn_voice.mp3'], capture_output=True)
stt = req('POST','/api/stt',token=tok,form={'audio':'@/tmp/pn_voice.mp3;type=audio/mpeg'})
print(f"🎧 STEP 1 — Whisper ได้ยิน: 「{stt.get('text','?')}」")

# STEP 2: ส่งข้อความที่ได้ยิน → สลี่คิด (AI)
q = stt.get('text','')
ai = req('POST','/api/ai',token=tok,data={'question':q})
reply = ai.get('reply','')
print(f"🧠 STEP 2 — สลี่ตอบ ({ai.get('model')}): 「{reply[:150]}...」")

# STEP 3: เสียงสลี่ตอบกลับ
r = subprocess.run(['bash','-c',f'curl -s -m 60 -X POST {BASE}/api/tts -H "Content-Type: application/json" -H "Authorization: Bearer {tok}" -d \'{{"text":"{reply[:200].replace(chr(34),"")}"}}\' -o /tmp/sali_reply.mp3 -w "%{{http_code}} %{{size_download}}"'], capture_output=True, text=True)
print(f"🔊 STEP 3 — เสียงสลี่ตอบ: HTTP {r.stdout.strip()}")

print("\n🎉 วงจรโทรครบวงจร: พูด → ได้ยิน → คิด → ตอบด้วยเสียง ทำงานแล้ว!")
