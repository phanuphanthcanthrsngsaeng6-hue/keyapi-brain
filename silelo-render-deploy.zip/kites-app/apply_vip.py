import re

def patch(path, pairs):
    s = open(path, encoding='utf-8').read()
    ok = True
    for old, new in pairs:
        if old not in s:
            print(f'  !! NOT FOUND in {path}: {old[:60]!r}')
            ok = False
            continue
        s = s.replace(old, new, 1)
    if ok:
        open(path, 'w', encoding='utf-8').write(s)
        print(f'  OK {path}')
    else:
        print(f'  SKIPPED WRITE {path} (missing patterns)')

# ============ 1) server.js ============
print('server.js:')
patch('/kites-app/server.js', [
    # Demo user -> Ultimate VIP, all milestones paid
    ("      role: 'client',\n      country: 'Thailand',\n      plan: 'Professional',\n      milestonesPaid: [],",
     "      role: 'client',\n      country: 'Thailand',\n      plan: 'Ultimate',\n      vip: true,\n      milestonesPaid: [1, 2, 3],"),
    # Add 3rd transaction (Final Delivery)
    ("      { id: crypto.randomUUID(), userId: 'u_demo', milestoneId: 2, title: 'Finish UX/UI Design', amount: 5200, method: 'Visa \u2022\u2022\u2022\u2022 4242', status: 'completed', time: Date.now() - 86400000 * 2 }\n    ];",
     "      { id: crypto.randomUUID(), userId: 'u_demo', milestoneId: 2, title: 'Finish UX/UI Design', amount: 5200, method: 'Visa \u2022\u2022\u2022\u2022 4242', status: 'completed', time: Date.now() - 86400000 * 2 },\n      { id: crypto.randomUUID(), userId: 'u_demo', milestoneId: 3, title: 'Final Delivery', amount: 3899, method: 'Visa \u2022\u2022\u2022\u2022 4242', status: 'completed', time: Date.now() - 86400000 }\n    ];"),
    # Mark all 3 milestones paid
    ("    db.package.milestones[0].status = 'paid';\n    db.package.milestones[1].status = 'paid';\n    db.users[0].milestonesPaid = [1, 2];",
     "    db.package.milestones[0].status = 'paid';\n    db.package.milestones[1].status = 'paid';\n    db.package.milestones[2].status = 'paid';\n    db.users[0].milestonesPaid = [1, 2, 3];"),
    # Expose vip in publicUser
    ("  return { id: u.id, name: u.name, email: u.email, role: u.role, country: u.country, plan: u.plan, milestonesPaid: u.milestonesPaid || [], createdAt: u.createdAt };",
     "  return { id: u.id, name: u.name, email: u.email, role: u.role, country: u.country, plan: u.plan, vip: u.vip || false, milestonesPaid: u.milestonesPaid || [], createdAt: u.createdAt };"),
])

# ============ 2) index.html ============
print('index.html:')
patch('/kites-app/public/index.html', [
    ('<span class="pill glass">PRO</span>', '<span class="pill glass gold">\U0001f451 ULTIMATE</span>'),
    ('<span class="pill pro-pill">\u2b50 PRO Client</span>', '<span class="pill pro-pill">\U0001f451 VIP \u00b7 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14</span>'),
    ('<span class="pill glass" id="profile-plan">Plan: Professional</span>', '<span class="pill glass gold" id="profile-plan">Plan: Ultimate \U0001f513</span>'),
    # VIP banner in payments screen
    ('<div class="milestones" id="milestones"></div>',
     '<div class="card vip-banner" id="vip-banner" style="display:none">\U0001f389 <span><b>\u0e1b\u0e25\u0e14\u0e25\u0e47\u0e2d\u0e04\u0e04\u0e23\u0e1a\u0e41\u0e25\u0e49\u0e27!</b> \u0e41\u0e1e\u0e47\u0e01\u0e40\u0e01\u0e08 Ultimate \u2014 \u0e17\u0e38\u0e01\u0e1f\u0e35\u0e40\u0e08\u0e2d\u0e23\u0e4c\u0e43\u0e0a\u0e49\u0e07\u0e32\u0e19\u0e44\u0e14\u0e49\u0e40\u0e15\u0e47\u0e21\u0e23\u0e39\u0e1b\u0e41\u0e1a\u0e1a</span></div>\n        <div class="milestones" id="milestones"></div>'),
    # Dynamic paid counter on home
    ('<div class="stat-up">2 / 3 \u0e07\u0e27\u0e14</div>', '<div class="stat-up" id="stat-paid-up">3 / 3 \u0e07\u0e27\u0e14</div>'),
])

# ============ 3) app.js ============
print('app.js:')
patch('/kites-app/public/app.js', [
    # renderProfile -> dynamic VIP
    ("  $('profile-plan').textContent = 'Plan: ' + (ME.plan || 'Professional');",
     "  const isVip = ME.plan === 'Ultimate' || ME.vip;\n  $('profile-plan').textContent = 'Plan: ' + (ME.plan || 'Professional') + (isVip ? ' \\U0001f513' : '');\n  const vipPill = document.querySelector('.pro-pill');\n  if (vipPill) vipPill.textContent = isVip ? '\\U0001f451 VIP \\u00b7 \\u0e23\\u0e30\\u0e14\\u0e31\\u0e1a\\u0e2a\\u0e39\\u0e07\\u0e2a\\u0e38\\u0e14' : '\\u2b50 PRO Client';"),
    # loadDashboard -> paid counter
    ("    $('stat-paid').textContent = money(st.paidSoFar);",
     "    $('stat-paid').textContent = money(st.paidSoFar);\n    const paidUp = $('stat-paid-up');\n    if (paidUp) paidUp.textContent = (st.paidSoFar >= st.packageTotal) ? '3 / 3 \\u0e07\\u0e27\\u0e14 \\u00b7 \\u0e04\\u0e23\\u0e1a\\u0e41\\u0e25\\u0e49\\u0e27 \\U0001f389' : '2 / 3 \\u0e07\\u0e27\\u0e14';"),
    # loadPackage -> show VIP banner when all paid
    ("    }).join('');\n    // transactions",
     "    }).join('');\n    const allPaid = paid.length >= pkg.milestones.length;\n    const banner = $('vip-banner');\n    if (banner) banner.style.display = allPaid ? 'flex' : 'none';\n    // transactions"),
    # AI reply reflects fully paid package
    ("\\u2022 \\u0e07\\u0e27\\u0e14\\u0e0a\\u0e33\\u0e23\\u0e30: 2/3 \\u0e07\\u0e27\\u0e14 ($9,100)",
     "\\u2022 \\u0e07\\u0e27\\u0e14\\u0e0a\\u0e33\\u0e23\\u0e30: 3/3 \\u0e04\\u0e23\\u0e1a\\u0e40\\u0e15\\u0e47\\u0e21 ($12,999) \\U0001f389"),
])

# ============ 4) style.css ============
print('style.css:')
patch('/kites-app/public/style.css', [
    (".pill.glass{ background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.14); color:var(--text); }",
     ".pill.glass{ background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.14); color:var(--text); }\n.pill.gold{ background:linear-gradient(135deg,rgba(251,191,36,.18),rgba(168,85,247,.18)); border:1px solid rgba(251,191,36,.45); color:#fbbf24; }\n.vip-banner{ display:flex; align-items:center; gap:10px; background:linear-gradient(135deg,rgba(251,191,36,.12),rgba(168,85,247,.14)); border:1px solid rgba(251,191,36,.35); margin-bottom:12px; font-size:.85rem; }\n.vip-banner b{ color:var(--amber); }"),
])
print('DONE')
