import json

# --- manifest.json ---
p = '/kites-app/public/manifest.json'
m = json.load(open(p, encoding='utf-8'))
m['name'] = 'Silelo💯✨️ — แอปพลิเคชันมือถือ AI'
m['short_name'] = 'Silelo'
m['description'] = 'แอปพลิเคชันมือถือ AI ครบวงจร โดย Silelo: AI Assistant, แชทเรียลไทม์, แผนที่, ชำระเงิน และ Analytics'
m['icons'] = [
    {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
    {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
    {"src": "/icon-maskable-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable"},
    {"src": "/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
    {"src": "/apple-touch-icon-180.png", "sizes": "180x180", "type": "image/png", "purpose": "any"},
]
json.dump(m, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('manifest.json OK')

# --- index.html: add favicon + apple-touch-icon + theme-color in <head> ---
h = '/kites-app/public/index.html'
s = open(h, encoding='utf-8').read()
head_add = '''<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
    <link rel="icon" type="image/png" sizes="64x64" href="/favicon-64.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180.png">
    <meta name="theme-color" content="#070a18">'''
if 'apple-touch-icon' not in s:
    # insert before </head>
    assert '</head>' in s
    s = s.replace('</head>', head_add + '\n  </head>', 1)
    open(h, 'w', encoding='utf-8').write(s)
    print('index.html head OK')
else:
    print('index.html already has icons')

# --- sw.js: precache new icons + bump cache ---
w = '/kites-app/public/sw.js'
sw = open(w, encoding='utf-8').read()
sw = sw.replace("const CACHE = 'silelo-app-v5';", "const CACHE = 'silelo-app-v6';")
sw = sw.replace(
    "const ASSETS = ['/', '/index.html', '/style.css?v=5', '/app.js?v=5', '/manifest.json', '/icon-192.png', '/icon-512.png'];",
    "const ASSETS = ['/', '/index.html', '/style.css?v=5', '/app.js?v=5', '/manifest.json', '/icon-192.png', '/icon-512.png', '/icon-1024.png', '/icon-maskable-192.png', '/icon-maskable-512.png', '/apple-touch-icon-180.png', '/favicon-32.png', '/favicon-64.png'];"
)
open(w, 'w', encoding='utf-8').write(sw)
print('sw.js OK')
print('--- verify head ---')
s = open(h, encoding='utf-8').read()
for line in s.splitlines():
    if 'icon' in line or 'theme-color' in line or 'title>' in line:
        print(line.strip())
