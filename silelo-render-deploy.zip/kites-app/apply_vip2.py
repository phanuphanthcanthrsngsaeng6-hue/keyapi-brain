def patch(path, pairs):
    s = open(path, encoding='utf-8').read()
    ok = True
    for old, new in pairs:
        if old not in s:
            print(f'  !! NOT FOUND in {path}: {old[:50]!r}')
            ok = False
            continue
        s = s.replace(old, new, 1)
    if ok:
        open(path, 'w', encoding='utf-8').write(s)
        print(f'  OK {path}')
    else:
        print(f'  SKIPPED WRITE {path}')

print('app.js:')
patch('/kites-app/public/app.js', [
    # renderProfile -> dynamic VIP
    ("  $('profile-plan').textContent = 'Plan: ' + (ME.plan || 'Professional');",
     "  const isVip = ME.plan === 'Ultimate' || ME.vip;\n  $('profile-plan').textContent = 'Plan: ' + (ME.plan || 'Professional') + (isVip ? ' 🔓' : '');\n  const vipPill = document.querySelector('.pro-pill');\n  if (vipPill) vipPill.textContent = isVip ? '👑 VIP · ระดับสูงสุด' : '⭐ PRO Client';"),
    # loadDashboard -> paid counter
    ("    $('stat-paid').textContent = money(st.paidSoFar);",
     "    $('stat-paid').textContent = money(st.paidSoFar);\n    const paidUp = $('stat-paid-up');\n    if (paidUp) paidUp.textContent = (st.paidSoFar >= st.packageTotal) ? '3 / 3 งวด · ครบแล้ว 🎉' : '2 / 3 งวด';"),
    # loadPackage -> VIP banner
    ("    }).join('');\n    // transactions",
     "    }).join('');\n    const allPaid = paid.length >= pkg.milestones.length;\n    const banner = $('vip-banner');\n    if (banner) banner.style.display = allPaid ? 'flex' : 'none';\n    // transactions"),
    # AI reply reflects fully paid package
    ("• งวดชำระ: 2/3 งวด ($9,100)",
     "• งวดชำระ: 3/3 ครบเต็ม ($12,999) 🎉"),
])

print('style.css:')
patch('/kites-app/public/style.css', [
    (".pro-pill{ background:rgba(251,191,36,.12); border:1px solid rgba(251,191,36,.35); color:var(--amber); }",
     ".pro-pill{ background:rgba(251,191,36,.12); border:1px solid rgba(251,191,36,.35); color:var(--amber); }\n.pill.gold{ background:linear-gradient(135deg,rgba(251,191,36,.18),rgba(168,85,247,.18)); border:1px solid rgba(251,191,36,.45); color:#fbbf24; }\n.vip-banner{ display:flex; align-items:center; gap:10px; background:linear-gradient(135deg,rgba(251,191,36,.12),rgba(168,85,247,.14)); border:1px solid rgba(251,191,36,.35); margin-bottom:12px; font-size:.85rem; }\n.vip-banner b{ color:var(--amber); }"),
])
print('DONE')
