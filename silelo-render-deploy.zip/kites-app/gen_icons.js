// Generate Kites App PNG icons (192 & 512) with pure Node (zlib + CRC)
const zlib = require('zlib');
const fs = require('fs');

// --- minimal PNG encoder ---
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4); crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}
function encodePNG(width, height, rgba) {
  const sig = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0; // filter none
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const idat = zlib.deflateSync(raw);
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', idat), chunk('IEND', Buffer.alloc(0))]);
}

// --- draw the kite icon ---
function hex(c) { return [parseInt(c.slice(1,3),16), parseInt(c.slice(3,5),16), parseInt(c.slice(5,7),16)]; }
const C_TOP = hex('#6366f1'), C_BOT = hex('#22d3ee'), C_BG = hex('#0b1026');
const C_TAIL = [255,255,255];

function lerp(a, b, t) { return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t]; }

function drawIcon(size) {
  const px = Buffer.alloc(size * size * 4);
  const cx = size / 2, cy = size / 2;
  const r = size * 0.36; // half-diagonal
  // diamond (kite) vertices
  const top = [cx, cy - r], right = [cx + r * 0.82, cy], bottom = [cx, cy + r], left = [cx - r * 0.82, cy];
  function inDiamond(x, y) {
    // point-in-convex-quad via cross products
    const pts = [top, right, bottom, left];
    let sign = null;
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      const cross = (b[0]-a[0])*(y-a[1]) - (b[1]-a[1])*(x-a[0]);
      if (Math.abs(cross) < 1e-9) continue;
      const s = cross > 0 ? 1 : -1;
      if (sign === null) sign = s; else if (s !== sign) return false;
    }
    return true;
  }
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      let c = C_BG, a = 255;
      // rounded corner mask (subtle)
      const cr = size * 0.22;
      const nx = Math.max(cr - x, 0, x - (size - cr));
      const ny = Math.max(cr - y, 0, y - (size - cr));
      if (nx * nx + ny * ny > cr * cr) { a = 0; }
      if (inDiamond(x + 0.5, y + 0.5)) {
        const t = (y - top[1]) / (bottom[1] - top[1]);
        c = lerp(C_TOP, C_BOT, Math.min(1, Math.max(0, t)));
        // inner highlight
        const dx = (x - cx), dy = (y - cy);
        if (dx*dx + dy*dy < (r*0.30)*(r*0.30)) c = lerp(c, [255,255,255], 0.10);
      }
      // tail dots below bottom vertex
      if (a !== 0) {
        const dBottom = bottom[1];
        const tailT = (y - dBottom) / (size * 0.14);
        if (tailT > 0 && tailT < 1) {
          const wave = Math.sin(tailT * 9) * size * 0.035;
          const dist = Math.abs(x - (cx + wave));
          if (dist < size * 0.018 * (1 - tailT * 0.4)) c = C_TAIL;
        }
      }
      px[i] = Math.round(c[0]); px[i+1] = Math.round(c[1]); px[i+2] = Math.round(c[2]); px[i+3] = a;
    }
  }
  return encodePNG(size, size, px);
}

const dir = '/kites-app/public';
fs.writeFileSync(dir + '/icon-192.png', drawIcon(192));
fs.writeFileSync(dir + '/icon-512.png', drawIcon(512));
console.log('icons generated:', fs.statSync(dir + '/icon-192.png').size, 'bytes /', fs.statSync(dir + '/icon-512.png').size, 'bytes');
