# -*- coding: utf-8 -*-
import subprocess, json, urllib.request, urllib.error

BASE = 'http://localhost:8080'

def post_json(path, token, data):
    rq = urllib.request.Request(BASE+path, data=json.dumps(data).encode(), method='POST')
    if token: rq.add_header('Authorization','Bearer '+token)
    rq.add_header('Content-Type','application/json')
    try:
        with urllib.request.urlopen(rq, timeout=120) as r: return json.loads(r.read().decode())
    except urllib.error.HTTPError as e: return json.loads(e.read().decode())

def post_audio(token, filepath, mime='audio/mpeg'):
    cmd = ['curl','-s','-m','120','-X','POST',BASE+'/api/stt','-H','Authorization: Bearer '+token,'-F',f'audio=@{filepath};type={mime}']
    return json.loads(subprocess.run(cmd, capture_output=True, text=True).stdout)

tok = post_json('/api/login', None, {'email':'demo@silelo.app','password':'demo1234'})['token']
print('✅ login')

subprocess.run(['bash','-c','edge-tts --voice th-TH-PremwadeeNeural --text "สวัสดีสลี่ พี่นุเหนื่อยมากวันนี้ ช่วยปลอบใจหน่อยนะ" --write-media /tmp/pn2.mp3'], capture_output=True)
stt = post_audio(tok, '/tmp/pn2.mp3')
q = stt.get('text','')
print(f'🎧 Whisper ได้ยิน: 「{q}」')

ai = post_json('/api/ai', tok, {'question': q})
reply = ai.get('reply','')
print(f'🧠 สลี่ตอบ ({ai.get("model")}): {reply[:180]}')

rq = urllib.request.Request(BASE+'/api/tts', data=json.dumps({'text': reply[:300]}).encode(), method='POST')
rq.add_header('Authorization','Bearer '+tok); rq.add_header('Content-Type','application/json')
with urllib.request.urlopen(rq, timeout=60) as r:
    audio = r.read()
    print(f'🔊 เสียงสลี่ตอบกลับ: {len(audio)} bytes — {r.headers.get("Content-Type")}')
    open('/tmp/sali_final.mp3','wb').write(audio)
print('\n🎉 วงจรโทรสมบูรณ์: พูด → ฟัง → คิด → ตอบด้วยเสียง ✅')
