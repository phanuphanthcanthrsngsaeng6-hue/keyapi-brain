# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

old = "const OPENROUTER_TEXT_MODELS = (process.env.OPENROUTER_TEXT_MODELS || 'openai/gpt-oss-20b:free,nvidia/nemotron-3-ultra-550b-a55b:free').split(',').map(s => s.trim()).filter(Boolean);"
new = "const OPENROUTER_TEXT_MODELS = (process.env.OPENROUTER_TEXT_MODELS || 'openai/gpt-oss-20b:free,nvidia/nemotron-3-ultra-550b-a55b:free,nvidia/nemotron-3.5-lightning:free,google/gemma-4-31b-it:free,nvidia/nemotron-3-super-120b-a12b:free').split(',').map(s => s.trim()).filter(Boolean);"
assert old in src
src = src.replace(old, new)

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ เพิ่มโมเดลฟรีสำรองแล้ว (5 ตัว)')

env = open('/kites-app/.env.example', encoding='utf-8').read()
env = env.replace("OPENROUTER_TEXT_MODELS=openai/gpt-oss-20b:free,nvidia/nemotron-3-ultra-550b-a55b:free",
                  "OPENROUTER_TEXT_MODELS=openai/gpt-oss-20b:free,nvidia/nemotron-3-ultra-550b-a55b:free,nvidia/nemotron-3.5-lightning:free,google/gemma-4-31b-it:free,nvidia/nemotron-3-super-120b-a12b:free")
open('/kites-app/.env.example', 'w', encoding='utf-8').write(env)
print('✅ .env.example อัปเดต')
