const fs = require('fs');
const { Resvg } = require('/kites-app/node_modules/@resvg/resvg-js');

const svg = fs.readFileSync('/kites-app/public/logo.svg', 'utf8');
const svgMask = fs.readFileSync('/kites-app/public/logo-maskable.svg', 'utf8');

function render(svgStr, size, out) {
  const r = new Resvg(svgStr, { fitTo: { mode: 'width', value: size } });
  const png = r.render().asPng();
  fs.writeFileSync(out, png);
  console.log(`  ${out} (${size}x${size}) ${(png.length/1024).toFixed(1)}KB`);
}

render(svg,     1024, '/kites-app/public/icon-1024.png');
render(svg,     512,  '/kites-app/public/icon-512.png');
render(svg,     192,  '/kites-app/public/icon-192.png');
render(svg,     180,  '/kites-app/public/apple-touch-icon-180.png');
render(svg,     64,   '/kites-app/public/favicon-64.png');
render(svg,     32,   '/kites-app/public/favicon-32.png');
render(svgMask, 512,  '/kites-app/public/icon-maskable-512.png');
render(svgMask, 192,  '/kites-app/public/icon-maskable-192.png');
console.log('DONE');
