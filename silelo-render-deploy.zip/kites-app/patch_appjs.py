# -*- coding: utf-8 -*-
import io

path = '/kites-app/public/app.js'
lines = open(path, encoding='utf-8').read().splitlines()
N = len(lines)
assert N >= 460, f'expected ~460 lines, got {N}'

# ---- Edit A: demo login toast (line 84, 1-indexed) ----
assert 'บัญชีทดลอง' in lines[83], lines[83]
lines[83] = "    toast('เข้าสู่ระบบบัญชีหลักแล้ว · ไร้ขีดจำกัด ∞');"

# ---- Edit B: renderProfile VIP block (lines 144-147) ----
assert 'isVip' in lines[143], lines[143]
lines[143] = "  const isUnlimited = ME.unlimited || ME.plan === 'Unlimited' || ME.role === 'owner';"
lines[144] = "  $('profile-plan').textContent = 'Plan: ' + (ME.plan || 'Professional') + (isUnlimited ? ' ∞' : '');"
lines[145] = "  const vipPill = document.querySelector('.pro-pill');"
lines[146] = "  if (vipPill) vipPill.textContent = isUnlimited ? '👑 บัญชีหลัก · ไร้ขีดจำกัด' : '⚡ PRO Client';"

# ---- Edit C: sendAI -> call server /api/ai (lines 243-256) ----
assert 'async function sendAI' in lines[243], lines[243]
new_sendAI = [
"let aiTyping = false;",
"async function sendAI() {",
"  const inp = $('ai-input');",
"  const q = inp.value.trim();",
"  if (!q || aiTyping) return;",
"  inp.value = '';",
"  addAIMsg(escapeHtml(q), true);",
"  aiTyping = true;",
"  const typing = addAIMsg('<span class=\"typing\">🤖 กำลังคิด...</span>');",
"  let reply = null;",
"  try {",
"    // 🔌 เรียก API AI ผ่าน server (พร้อมสลับเป็น GPT/Gemini จริงเมื่อมีคีย์)",
"    const data = await api('/api/ai', { method: 'POST', body: JSON.stringify({ question: q }) });",
"    reply = data.reply || aiReply(q);",
"  } catch (e) {",
"    await new Promise(r => setTimeout(r, 600));",
"    reply = aiReply(q); // fallback โหมดสาธิตเมื่อออฟไลน์",
"  }",
"  typing.querySelector('.bubble').innerHTML = reply.replace(/\\*\\*/g, '').replace(/\\n/g, '<br>');",
"  aiTyping = false;",
"  $('ai-chat').scrollTop = $('ai-chat').scrollHeight;",
"}",
]
lines[243:256] = new_sendAI  # replaces 13 old lines with 21

open(path, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('app.js updated OK, lines:', len(lines))
