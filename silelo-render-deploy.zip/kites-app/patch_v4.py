# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

old = "const DEEPSEEK_MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-chat'; // deepseek-chat (V3) หรือ deepseek-reasoner (R1)"
new = "const DEEPSEEK_MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-v4-flash'; // 🔥 V4 Flash ใหม่ล่าสุด (ถูกกว่า V3 อีก) — ใช้ได้กับคีย์พี่บอส"
assert old in src
src = src.replace(old, new)

# คอมเมนต์ env เก่าใน .env.example
env = open('/kites-app/.env.example', encoding='utf-8').read()
env = env.replace("DEEPSEEK_MODEL=deepseek-chat", "DEEPSEEK_MODEL=deepseek-v4-flash")
open('/kites-app/.env.example', 'w', encoding='utf-8').write(env)

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ เปลี่ยนเป็น deepseek-v4-flash แล้ว')

# render.yaml
ry = open('/kites-app/render.yaml', encoding='utf-8').read()
ry = ry.replace("""      - key: DEEPSEEK_API_KEY
        value: sk-a63c4b4476f549c3800b57328570c6ee""",
"""      - key: DEEPSEEK_API_KEY
        value: sk-a63c4b4476f549c3800b57328570c6ee
      - key: DEEPSEEK_MODEL
        value: deepseek-v4-flash""")
open('/kites-app/render.yaml', 'w', encoding='utf-8').write(ry)
print('✅ render.yaml เพิ่ม DEEPSEEK_MODEL')
