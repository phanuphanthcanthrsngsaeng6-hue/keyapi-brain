# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()

# 1) เพิ่ม config DeepSeek ถัดจาก OPENROUTER_KEYS
anchor = "const OPENROUTER_IMAGE_MODEL = process.env.OPENROUTER_IMAGE_MODEL || 'google/gemini-2.5-flash-image';"
deepseek_cfg = """const OPENROUTER_IMAGE_MODEL = process.env.OPENROUTER_IMAGE_MODEL || 'google/gemini-2.5-flash-image';
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || 'sk-a63c4b4476f549c3800b57328570c6ee'; // คีย์ DeepSeek ของพี่บอส (เติมเงินแล้วใช้ได้ทันที)
const DEEPSEEK_MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-chat'; // deepseek-chat (V3) หรือ deepseek-reasoner (R1)"""
assert anchor in src
src = src.replace(anchor, deepseek_cfg)

# 2) เพิ่มฟังก์ชัน deepseekChat ก่อน openrouterChat
anchor2 = "async function openrouterChat(messages) {"
deepseek_fn = """async function deepseekChat(messages) {
  if (!DEEPSEEK_API_KEY) return null;
  try {
    const r = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + DEEPSEEK_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: DEEPSEEK_MODEL, max_tokens: 800, messages })
    });
    const j = await r.json();
    if (!r.ok) {
      const msg = (j.error && j.error.message) || '';
      // คีย์เสีย/ไม่มีเครดิต (401/402/Insufficient) → ข้ามไป provider ถัดไปทันที (ไม่เสียเวลา)
      if (r.status === 401 || r.status === 402 || /insufficient|invalid|authentication/i.test(msg)) return null;
      throw new Error('DeepSeek ' + r.status + ': ' + msg.slice(0, 100));
    }
    const reply = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (!reply) return null;
    return { provider: 'deepseek', model: DEEPSEEK_MODEL, reply };
  } catch (e) { return null; }
}

async function openrouterChat(messages) {"""
assert anchor2 in src
src = src.replace(anchor2, deepseek_fn)

# 3) askAI: DeepSeek → OpenRouter → mock
anchor3 = """  const or = await openrouterChat(msgs);
  if (or) return or;"""
new_chain = """  const ds = await deepseekChat(msgs); // 🥇 DeepSeek (คีย์พี่บอส) — เติมเงินแล้วใช้ได้ทันที
  if (ds) return ds;
  const or = await openrouterChat(msgs); // 🥈 โมเดลฟรี
  if (or) return or;"""
assert anchor3 in src
src = src.replace(anchor3, new_chain)

open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ DeepSeek provider เพิ่มแล้ว')

# 4) .env.example
env = open('/kites-app/.env.example', encoding='utf-8').read()
env += "\n# 🐋 DeepSeek API (เติมเงินที่ platform.deepseek.com — ถูกมาก ~$0.27/1M คำ)\nDEEPSEEK_API_KEY=sk-a63c4b4476f549c3800b57328570c6ee\nDEEPSEEK_MODEL=deepseek-chat\n"
open('/kites-app/.env.example', 'w', encoding='utf-8').write(env)
print('✅ .env.example อัปเดต')

# 5) render.yaml
ry = open('/kites-app/render.yaml', encoding='utf-8').read()
ry = ry.replace("      # 🎨 โมเดลสร้างภาพสำรอง",
"""      # 🐋 DeepSeek (คีย์พี่บอส — ใช้เมื่อเติมเงินแล้ว)
      - key: DEEPSEEK_API_KEY
        value: sk-a63c4b4476f549c3800b57328570c6ee
      # 🎨 โมเดลสร้างภาพสำรอง""")
open('/kites-app/render.yaml', 'w', encoding='utf-8').write(ry)
print('✅ render.yaml อัปเดต')
