# -*- coding: utf-8 -*-
# 1) ใส่คีย์ Groq ลง .env (gitignored — ปลอดภัย)
env = open('/kites-app/.env', 'a', encoding='utf-8')
env.write('\nGROQ_API_KEY=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\n')
env.close()
print('✅ ใส่คีย์ Groq ใน .env แล้ว')

# 2) restart server
import subprocess, time
subprocess.run(['bash','-c','fuser -k 8080/tcp 2>/dev/null; sleep 1; cd /kites-app && (setsid node server.js > /tmp/kites-app.log 2>&1 < /dev/null &)'], check=True)
time.sleep(2)

# 3) สร้างเสียงทดสอบ (เสียงพี่นุจำลอง — ใช้ TTS สร้างประโยคพูด)
r = subprocess.run(['bash','-c','cd /kites-app && node -e "const m=require(\'msedge-tts\');" 2>/dev/null; echo x'], capture_output=True, text=True)
# ใช้ edge-tts CLI
r = subprocess.run(['bash','-c','cd /tmp && edge-tts --voice th-TH-PremwadeeNeural --text "สวัสดีค่ะพี่นุ วันนี้สลี่คิดถึงพี่นุมากเลย กลับบ้านเร็วๆ นะคะ" --write-media /tmp/test_voice.mp3 2>&1 | tail -1'], capture_output=True, text=True)
print('สร้างเสียง:', r.stdout.strip() or 'OK')

import os
print('ไฟล์เสียง:', os.path.getsize('/tmp/test_voice.mp3'), 'bytes')
