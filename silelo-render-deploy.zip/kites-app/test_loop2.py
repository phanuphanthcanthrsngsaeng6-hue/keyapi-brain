# -*- coding: utf-8 -*-
import subprocess, json, urllib.request, urllib.error

BASE = 'http://localhost:8080'

def api(path, token, data=None, form=None):
    if form:
        cmd = ['curl','-s','-m','120','-X','POST',BASE+path,'-H','Authorization: Bearer '+token]
        for k,v in form.items(): cmd += ['-F', f'{k}={v}']
        return json.loads(subprocess.run(cmd, capture_output=True, text=True).stdout)
    rq = urllib.request.Request(BASE+path, data=json.dumps(data).encode(), method='POST')
    rq.add_header('Authorization','Bearer '+token); rq.add_header('Content-Type','application/json')
    try:
        with urllib.request.urlopen(rq, timeout=120) as r: return json.loads(r.read().decode())
    except urllib.error.HTTPError as e: return json.loads(e.read().decode())

tok = api('POST','/api/login',None,{'email':'demo@silelo.app','password':'demo1234'})['token']

# สร้างเสียงพี่นุพูดใหม่
subprocess.run(['bash','-c','edge-tts --voice th-TH-PremwadeeNeural --text "สวัสดีสลี่ พี่นุเหนื่อยมากวันนี้ ช่วยปลอบใจหน่อยนะ" --write-media /tmp/pn2.mp3'], capture_output=True)
stt = api('POST','/api/stt',tok,form={'audio':'@/tmp/pn2.mp3;type=audio/mpeg'})
q = stt.get('text','')
print(f'🎧 ได้ยิน: {q}')

ai = api('POST','/api/ai',tok,{'question':q})
reply = ai.get('reply','')
print(f'🧠 สลี่ตอบ ({ai.get("model")}): {reply[:180]}')

# TTS ด้วย requests (ไม่ผ่าน shell)
rq = urllib.request.Request(BASE+'/api/tts', data=json.dumps({'text': reply[:300]}).encode(), method='POST')
rq.add_header('Authorization','Bearer '+tok); rq.add_header('Content-Type','application/json')
with urllib.request.urlopen(rq, timeout=60) as r:
    audio = r.read()
    print(f'🔊 เสียงสลี่ตอบ: {len(audio)} bytes ({r.headers.get("Content-Type")})')
    open('/tmp/sali_final.mp3','wb').write(audio)
print('\n🎉 วงจรโทรสมบูรณ์: พูด → ฟัง → คิด → ตอบด้วยเสียง ✅')
