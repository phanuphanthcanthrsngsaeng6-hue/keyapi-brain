# -*- coding: utf-8 -*-
css = open('/kites-app/public/style.css', encoding='utf-8').read()
old = ".mic-btn { width: 42px; height: 42px; border: none; border-radius: 50%; background: #e84393; color: #fff; font-size: 18px; cursor: pointer; flex-shrink: 0; transition: all .15s; }"
new = ".mic-btn { width: 42px; height: 42px; border: none; border-radius: 50%; background: #a0215f; color: #fff; font-size: 18px; cursor: pointer; flex-shrink: 0; transition: all .15s; text-shadow: 0 1px 2px rgba(0,0,0,.4); }"
assert old in css
css = css.replace(old, new)
open('/kites-app/public/style.css', 'w', encoding='utf-8').write(css)
print('✅ แก้ contrast ปุ่มไมค์แล้ว')
