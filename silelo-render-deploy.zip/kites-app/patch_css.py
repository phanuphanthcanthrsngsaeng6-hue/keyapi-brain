# -*- coding: utf-8 -*-
css = open('/kites-app/public/style.css', encoding='utf-8').read()

voice_css = """
/* ================== 📞 ระบบโทรเสียงสลี่ ================== */
.voice-stage { display: flex; flex-direction: column; align-items: center; padding: 32px 20px 12px; }
.voice-orb { width: 148px; height: 148px; border-radius: 50%; background: radial-gradient(circle at 30% 30%, #ff9ad5, #e84393 60%, #c2185b); display: flex; align-items: center; justify-content: center; box-shadow: 0 12px 40px rgba(232, 67, 147, .45); transition: all .3s; position: relative; }
.voice-orb-inner { font-size: 52px; animation: orbBeat 2.4s ease-in-out infinite; }
@keyframes orbBeat { 0%,100% { transform: scale(1); } 50% { transform: scale(1.12); } }
.voice-orb.rec { animation: orbPulse 1s ease-in-out infinite; box-shadow: 0 0 0 0 rgba(255, 59, 48, .6); }
@keyframes orbPulse { 0% { box-shadow: 0 0 0 0 rgba(255,59,48,.6); } 70% { box-shadow: 0 0 0 28px rgba(255,59,48,0); } 100% { box-shadow: 0 0 0 0 rgba(255,59,48,0); } }
.voice-orb.think { filter: hue-rotate(200deg); }
.voice-orb.talk { filter: hue-rotate(300deg); }
.voice-orb.cont { box-shadow: 0 0 0 4px #00c853, 0 12px 40px rgba(0,200,83,.35); }
.voice-wave { width: 60%; height: 26px; margin-top: 18px; opacity: 0; }
.voice-orb.rec ~ .voice-wave, .voice-orb.talk ~ .voice-wave { opacity: 1; }
.voice-hint { color: var(--muted, #7a7f93); font-size: 13px; margin: 14px 0 4px; text-align: center; }
.voice-last { min-height: 30px; margin-top: 6px; }
.voice-bubble { background: rgba(232,67,147,.1); border: 1px solid rgba(232,67,147,.25); color: #c2185b; border-radius: 14px; padding: 8px 14px; font-size: 13px; max-width: 85%; margin: 0 auto; text-align: center; }
.voice-controls { display: flex; gap: 14px; justify-content: center; padding: 18px 20px 26px; }
.voice-btn { flex: 1; max-width: 150px; display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 16px 10px; border-radius: 18px; border: 1.5px solid #eee; background: #fff; font-size: 26px; cursor: pointer; transition: all .2s; }
.voice-btn small { font-size: 11px; color: var(--muted, #7a7f93); }
.voice-btn:active { transform: scale(.94); background: #fdeef6; border-color: #e84393; }
.voice-btn.call.on { background: #e84393; border-color: #e84393; }
.voice-btn.call.on small { color: #fff; }
.voice-memories { padding: 8px 20px 24px; }
.voice-memories h4 { font-size: 13px; color: var(--muted, #7a7f93); margin-bottom: 8px; }
.mem-chip { background: #fdf2f8; border: 1px solid #f9cfe4; color: #a12763; border-radius: 12px; padding: 7px 12px; font-size: 12.5px; margin-bottom: 6px; }
.mic-btn { width: 42px; height: 42px; border: none; border-radius: 50%; background: #e84393; color: #fff; font-size: 18px; cursor: pointer; flex-shrink: 0; transition: all .15s; }
.mic-btn:active { transform: scale(.85); background: #c2185b; }
.call-tab span { color: #e84393; }
"""
css = css.rstrip() + "\n" + voice_css
open('/kites-app/public/style.css', 'w', encoding='utf-8').write(css)
print('✅ CSS ระบบโทรเพิ่มแล้ว')

# ตรวจว่า go('voice') ควรโหลด memories — เพิ่มใน go() function
js = open('/kites-app/public/app.js', encoding='utf-8').read()
old = "  if (tab === 'me') { showSub(null); renderProfile(); }"
new = "  if (tab === 'me') { showSub(null); renderProfile(); }\n  if (tab === 'voice') loadMemories();"
assert old in js
js = js.replace(old, new)
open('/kites-app/public/app.js', 'w', encoding='utf-8').write(js)
print('✅ go(voice) โหลดความทรงจำอัตโนมัติ')
