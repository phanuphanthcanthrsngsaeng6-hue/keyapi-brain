import json
db = json.load(open('/kites-app/data/db.json'))
print('ผู้ใช้:', len(db['users']))
print('ข้อความแชท:', len(db['messages']))
print('ธุรกรรม:', len(db['transactions']))
print('งวดชำระ:')
for m in db['package']['milestones']:
    print(f"  - {m['title']}: {m['status']} (${m['amount']:,})")
print('ข้อความล่าสุด:', db['messages'][-1]['text'][:50])
t = db['transactions'][0]
print('ธุรกรรมล่าสุด:', t['title'], '|', t['method'], '|', t['amount'])
