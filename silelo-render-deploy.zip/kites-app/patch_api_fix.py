# -*- coding: utf-8 -*-
js = open('/kites-app/public/app.js', encoding='utf-8').read()

old = """async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}),
      ...(opts.headers || {})
    }
  });"""
new = """async function api(path, opts = {}) {
  const isForm = opts.body instanceof FormData;
  const res = await fetch(API + path, {
    ...opts,
    headers: {
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
      ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}),
      ...(opts.headers || {})
    }
  });"""
assert old in js
js = js.replace(old, new)

# แก้ processVoice: ไม่ต้อง raw:true (detect อัตโนมัติ)
js = js.replace("{ method: 'POST', body: fd, raw: true }", "{ method: 'POST', body: fd }")

# แก้ processVoice: ตรวจ d.ok — api() จะ throw เมื่อ !ok — ปรับ catch ให้จับได้
old2 = """    const d = await api('/api/stt', { method: 'POST', body: fd });
    if (!d.ok) { voiceStatus('⚠️ ' + (d.error || 'STT ล้มเหลว')); return; }
    text = d.text;"""
new2 = """    const d = await api('/api/stt', { method: 'POST', body: fd });
    text = d.text || '';"""
assert old2 in js
js = js.replace(old2, new2)

open('/kites-app/public/app.js', 'w', encoding='utf-8').write(js)
print('✅ api() รองรับ FormData แล้ว + แก้ processVoice')
