# -*- coding: utf-8 -*-
src = open('/kites-app/server.js', encoding='utf-8').read()
old = "const OPENROUTER_TEXT_MODELS = (process.env.OPENROUTER_TEXT_MODELS || 'openai/gpt-oss-20b:free,nvidia/nemotron-3.5-lightning:free,nvidia/nemotron-3-ultra-550b-a55b:free,google/gemma-4-31b-it:free,nvidia/nemotron-3-super-120b-a12b:free').split(',').map(s => s.trim()).filter(Boolean);"
new = "const OPENROUTER_TEXT_MODELS = (process.env.OPENROUTER_TEXT_MODELS || 'openai/gpt-oss-20b:free,google/gemma-4-31b-it:free,nvidia/nemotron-3-ultra-550b-a55b:free,nvidia/nemotron-3-super-120b-a12b:free,nvidia/nemotron-3.5-lightning:free').split(',').map(s => s.trim()).filter(Boolean);"
assert old in src
src = src.replace(old, new)
open('/kites-app/server.js', 'w', encoding='utf-8').write(src)
print('✅ เรียงใหม่: lightning เป็นตัวสุดท้าย')

# ทดสอบ gemma-4-31b กับคีย์พี่บอส ว่าตอบไทยดีไหม
